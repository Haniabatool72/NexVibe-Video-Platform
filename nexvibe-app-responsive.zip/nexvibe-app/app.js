"use strict";
/* =========================================================================================
   NEXVIBE — data layer, state, router, views, player controller, event wiring
   ========================================================================================= */

/* ---------------------------------- ICONS ---------------------------------- */
const ICON = {
  home:'<path d="M4 11.5 12 4l8 7.5"/><path d="M6 10v9a1 1 0 0 0 1 1h4v-6h2v6h4a1 1 0 0 0 1-1v-9"/>',
  compass:'<circle cx="12" cy="12" r="9"/><path d="M15 9l-2 6-6 2 2-6 6-2z"/>',
  users:'<circle cx="9" cy="8" r="3"/><path d="M2 20c0-3.3 3.1-6 7-6s7 2.7 7 6"/><circle cx="18" cy="9" r="2.4"/><path d="M15.5 14.2c2.6.4 5 2.2 5 5.8"/>',
  history:'<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/><path d="M12 8v4l3 2"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/>',
  thumbUp:'<path d="M7 11v9H4a1 1 0 0 1-1-1v-7a1 1 0 0 1 1-1h3zm0 0 4-8a2 2 0 0 1 2 2v4h5.2a2 2 0 0 1 2 2.4l-1.5 7A2 2 0 0 1 16.7 20H10a3 3 0 0 1-3-3"/>',
  thumbDown:'<path d="M17 13V4h3a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1h-3zm0 0-4 8a2 2 0 0 1-2-2v-4H5.8a2 2 0 0 1-2-2.4l1.5-7A2 2 0 0 1 7.3 4H14a3 3 0 0 1 3 3"/>',
  star:'<path d="M12 3l2.6 5.9 6.4.6-4.8 4.3 1.4 6.3L12 17l-5.6 3.1 1.4-6.3-4.8-4.3 6.4-.6z"/>',
  list:'<path d="M9 6h12M9 12h12M9 18h12"/><circle cx="4" cy="6" r="1.4"/><circle cx="4" cy="12" r="1.4"/><circle cx="4" cy="18" r="1.4"/>',
  settings:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.2a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.2a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.2a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.2a1.6 1.6 0 0 0-1.5 1z"/>',
  bell:'<path d="M6 9a6 6 0 1 1 12 0c0 5 2 6 2 6H4s2-1 2-6"/><path d="M9.5 20a2.5 2.5 0 0 0 5 0"/>',
  search:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
  sun:'<circle cx="12" cy="12" r="4.5"/><path d="M12 2v2.5M12 19.5V22M4.2 4.2l1.8 1.8M18 18l1.8 1.8M2 12h2.5M19.5 12H22M4.2 19.8 6 18M18 6l1.8-1.8"/>',
  moon:'<path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5z"/>',
  menu:'<path d="M3 6h18M3 12h18M3 18h18"/>',
  close:'<path d="M6 6l12 12M18 6L6 18"/>',
  play:'<path d="M8 5.5v13l11-6.5z"/>',
  pause:'<path d="M7 5h4v14H7zM13 5h4v14h-4z"/>',
  volume:'<path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="M16 8.5a5 5 0 0 1 0 7"/><path d="M18.5 6a8.5 8.5 0 0 1 0 12"/>',
  mute:'<path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="M16 9l5 6M21 9l-5 6"/>',
  fullscreen:'<path d="M4 9V5a1 1 0 0 1 1-1h4M20 9V5a1 1 0 0 0-1-1h-4M4 15v4a1 1 0 0 0 1 1h4M20 15v4a1 1 0 0 1-1 1h-4"/>',
  share:'<circle cx="18" cy="5" r="2.6"/><circle cx="6" cy="12" r="2.6"/><circle cx="18" cy="19" r="2.6"/><path d="M8.3 10.7l7.4-4.2M8.3 13.3l7.4 4.2"/>',
  dots:'<circle cx="12" cy="5" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="12" cy="19" r="1.6"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  check:'<path d="M4 12l5 5 11-11"/>',
  chevDown:'<path d="M6 9l6 6 6-6"/>',
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 20c0-4.4 3.6-7 8-7s8 2.6 8 7"/>',
  logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
  trash:'<path d="M4 7h16M9 7V4h6v3M6 7l1 13a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-13"/>',
  reply:'<path d="M9 14l-5-5 5-5"/><path d="M4 9h10a6 6 0 0 1 6 6v3"/>',
  key:'<circle cx="8" cy="15" r="4"/><path d="M11 12l8-8M16 8l2 2M19 5l2 2"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6"/><circle cx="12" cy="7.5" r="1"/>',
  link:'<path d="M9 15l6-6"/><path d="M13 6l1.5-1.5a3.5 3.5 0 1 1 5 5L18 11"/><path d="M11 18l-1.5 1.5a3.5 3.5 0 1 1-5-5L6 13"/>',
  film:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4M17 9h4M3 15h4M17 15h4"/>',
  upload:'<path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/>',
  eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>',
  globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
  warn:'<path d="M12 3l10 18H2z"/><path d="M12 10v4M12 17h.01"/>',
  copy:'<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M4 16V4a2 2 0 0 1 2-2h10"/>',
  refresh:'<path d="M4 12a8 8 0 0 1 14-5.3L21 9"/><path d="M21 3v6h-6"/><path d="M20 12a8 8 0 0 1-14 5.3L3 15"/><path d="M4 21v-6h6"/>',
};
function ic(name,size=20){return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${ICON[name]||''}</svg>`;}

/* ---------------------------------- HELPERS ---------------------------------- */
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function hash(str){let h=0;for(let i=0;i<str.length;i++){h=(h<<5)-h+str.charCodeAt(i);h|=0;}return Math.abs(h);}
function seedNum(id,min,max){return min+(hash(id)%(max-min));}
function fmtViews(n){
  if(n>=1e9)return (n/1e9).toFixed(1).replace(/\.0$/,'')+'B';
  if(n>=1e6)return (n/1e6).toFixed(1).replace(/\.0$/,'')+'M';
  if(n>=1e3)return (n/1e3).toFixed(1).replace(/\.0$/,'')+'K';
  return String(n);
}
function fmtAgo(days){
  if(days<1)return 'Today';
  if(days<2)return 'Yesterday';
  if(days<7)return days+' days ago';
  if(days<30)return Math.floor(days/7)+(Math.floor(days/7)===1?' week ago':' weeks ago');
  if(days<365)return Math.floor(days/30)+(Math.floor(days/30)===1?' month ago':' months ago');
  return Math.floor(days/365)+(Math.floor(days/365)===1?' year ago':' years ago');
}
function fmtDur(sec){sec=Math.floor(sec||0);const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;
  return (h?h+':'+String(m).padStart(2,'0'):m)+':'+String(s).padStart(2,'0');}
function fmtClock(sec){return fmtDur(sec);}
function timeAgoShort(ts){const d=(Date.now()-ts)/1000;if(d<60)return 'just now';if(d<3600)return Math.floor(d/60)+'m ago';
  if(d<86400)return Math.floor(d/3600)+'h ago';return Math.floor(d/86400)+'d ago';}
function uid(){return 'x'+Math.random().toString(36).slice(2,10);}
function avatarUrl(seed,bg){return `https://api.dicebear.com/7.x/shapes/svg?seed=${encodeURIComponent(seed)}&backgroundColor=${bg||'0a0e17'}`;}
function personUrl(seed){return `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(seed)}&backgroundColor=161924`;}
function thumbUrl(seed,w=640,h=360){return `https://picsum.photos/seed/${encodeURIComponent(seed)}/${w}/${h}`;}
function bannerUrl(seed){return `https://picsum.photos/seed/${encodeURIComponent(seed+'-banner')}/1200/300`;}

/* ---------------------------------- MOCK DATA ---------------------------------- */
const CATEGORIES = [
  {key:'all',label:'All'},{key:'tech',label:'Tech'},{key:'music',label:'Music'},{key:'gaming',label:'Gaming'},
  {key:'news',label:'News'},{key:'movies',label:'Movies'},{key:'sports',label:'Sports'},
  {key:'education',label:'Education'},{key:'comedy',label:'Comedy'}
];
const CHANNELS = {
  novacircuit:{name:'NovaCircuit',handle:'@novacircuit',category:'tech',desc:'Deep dives into next-gen hardware, interfaces and the tech reshaping how we live.'},
  kineticlabs:{name:'Kinetic Labs',handle:'@kineticlabs',category:'tech',desc:'Builders documenting hands-on experiments in robotics and rapid prototyping.'},
  nightcode:{name:'Nightcode',handle:'@nightcode',category:'tech',desc:'Late-night engineering talks on chips, AI systems and the software underneath.'},
  pulsewave:{name:'PulseWave',handle:'@pulsewave',category:'music',desc:'Live sets and studio sessions from the edge of synth and bass music.'},
  chromatic:{name:'Chromatic Sessions',handle:'@chromaticsessions',category:'music',desc:'A weekly series recording intimate lo-fi and ambient performances.'},
  aurorascore:{name:'Aurora Score',handle:'@aurorascore',category:'music',desc:'Original productions, official videos and behind-the-scenes studio breakdowns.'},
  orbitalarcade:{name:'Orbital Arcade',handle:'@orbitalarcade',category:'gaming',desc:'Ranked grinds, first looks and community events across the newest releases.'},
  halcyon:{name:'Halcyon Gaming',handle:'@halcyongaming',category:'gaming',desc:'Reaction breakdowns, hidden-gem roundups and hardware builds for gamers.'},
  signalnine:{name:'SignalNine',handle:'@signalnine',category:'news',desc:'Nightly coverage of policy, technology and the stories shaping the region.'},
  meridian:{name:'Meridian News',handle:'@meridiannews',category:'news',desc:'Explainers that break down complex stories into what actually matters.'},
  driftframe:{name:'DriftFrame Cinema',handle:'@driftframe',category:'movies',desc:'Trailers, breakdowns and behind-the-scenes footage from independent film.'},
  flux:{name:'Flux Studios',handle:'@fluxstudios',category:'movies',desc:'A studio collective sharing short films, scores and production insight.'},
  vantage:{name:'Vantage Sports',handle:'@vantagesports',category:'sports',desc:'Weekly highlights, training breakdowns and the stories behind the season.'},
  quanta:{name:'Quanta Learn',handle:'@quantalearn',category:'education',desc:'Clear, visual explainers on science and ideas worth understanding well.'},
  loopline:{name:'Loopline Comedy',handle:'@loopline',category:'comedy',desc:'Sketches, stand-up and improv from a collective that never takes it too seriously.'}
};
Object.keys(CHANNELS).forEach(id=>{
  const c=CHANNELS[id];
  c.id=id; c.avatar=avatarUrl(id); c.banner=bannerUrl(id);
  c.subs=seedNum(id,4200,3200000);
});
const RAW_VIDEOS=[
["Neural Interfaces: The Next Decade","tech","novacircuit"],
["I Built a Holographic Desk in 48 Hours","tech","kineticlabs"],
["Quantum Chips vs Classical Silicon","tech","nightcode"],
["Inside the Lab: Synthetic Retinas","tech","novacircuit"],
["Unboxing the Aether X1 Drone","tech","kineticlabs"],
["Why Edge AI Changes Everything","tech","nightcode"],
["Midnight Circuit — Full Live Session","music","pulsewave"],
["Synth Waves: Building a Track From Scratch","music","chromatic"],
["Aurora Score — Orbital (Official Video)","music","aurorascore"],
["Chromatic Sessions Ep. 12: Lo-Fi Nights","music","chromatic"],
["PulseWave Live at Neon District","music","pulsewave"],
["How I Produce a Song in One Sitting","music","aurorascore"],
["Starforged Ascension — First 2 Hours","gaming","orbitalarcade"],
["Speedrunning Nebula Drift World Record","gaming","halcyon"],
["Orbital Arcade Ranked Grind: Diamond Push","gaming","orbitalarcade"],
["Halcyon Reacts: New Trailer Breakdown","gaming","halcyon"],
["Building the Ultimate Sim Rig","gaming","orbitalarcade"],
["Top 10 Hidden Gems You Missed","gaming","halcyon"],
["SignalNine Nightly: Orbital Trade Talks","news","signalnine"],
["Meridian Explains: The New Energy Grid","news","meridian"],
["Field Report: Coastal Rebuild Project","news","signalnine"],
["SignalNine Nightly: Tech Regulation Roundup","news","signalnine"],
["Meridian Explains: Climate Adaptation Cities","news","meridian"],
["Behind the Story: Data Privacy Bill","news","meridian"],
["DRIFT — Official Trailer","movies","driftframe"],
["Behind the Scenes: Practical Effects of DRIFT","movies","driftframe"],
["Flux Studios Shortfilm: The Last Signal","movies","flux"],
["Top 5 Cinematography Tricks of 2026","movies","flux"],
["DriftFrame Reacts: Trailer Breakdown","movies","driftframe"],
["The Making of Flux Studios' New Score","movies","flux"],
["Vantage Weekly: Top 10 Plays","sports","vantage"],
["Inside Training: Recovery Tech Explained","sports","vantage"],
["Grand Finals Recap: Full Highlights","sports","vantage"],
["Vantage Sports Draft Special","sports","vantage"],
["The Science of Sprint Starts","sports","vantage"],
["Underdog Story: Rookie Season Recap","sports","vantage"],
["Quantum Computing Explained Simply","education","quanta"],
["How Neural Networks Actually Learn","education","quanta"],
["The Physics of Everyday Things","education","quanta"],
["Crash Course: Orbital Mechanics","education","quanta"],
["Understanding Cryptography in 10 Minutes","education","quanta"],
["Why Time Feels Different at Scale","education","quanta"],
["Loopline Sketch: The AI Interview","comedy","loopline"],
["Stand-Up: Life in a Smart City","comedy","loopline"],
["Loopline Sketch: Customer Support Bot","comedy","loopline"],
["Improv Night: Random Prompts Live","comedy","loopline"],
["Loopline Sketch: The Group Chat","comedy","loopline"],
["Stand-Up: Dating in 2026","comedy","loopline"]
];
const SAMPLE_FILES=[
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4"
];
const DESC_TEMPLATES={
tech:"A hands-on look at where this technology is heading next, what's actually working today, and what's still years away from your desk.",
music:"Recorded in a single take with minimal overdubs — turn the lights down and let this one run.",
gaming:"Full session, no cuts. Comments are open if you want the settings or route breakdown.",
news:"An explainer covering what changed, why it matters, and what to watch for next.",
movies:"A look behind the frame — the choices, the constraints, and the craft that shaped it.",
sports:"Highlights and analysis from a week that had a bit of everything.",
education:"A visual walkthrough built to make a hard idea click in under fifteen minutes.",
comedy:"Written the same week it was shot. No notes, mostly."
};
const VIDEOS = RAW_VIDEOS.map((r,i)=>{
  const id='v'+(i+1);
  const [title,category,channelId]=r;
  const h=hash(id);
  return {
    id, title, category, channelId, source:'mock',
    file:SAMPLE_FILES[i%SAMPLE_FILES.length],
    thumb:thumbUrl(id),
    views:seedNum(id,850,9400000),
    likesCount:seedNum(id+'l',40,210000),
    dislikesCount:seedNum(id+'d',2,4000),
    daysAgo: (h%420)+1,
    duration: 90+(h%1400),
    live: (h%23===0),
    description: DESC_TEMPLATES[category]+"\n\nChapters, gear lists and source notes linked where relevant. Thanks for watching NexVibe.",
    tags:[category, CHANNELS[channelId].name.split(' ')[0], 'NexVibe']
  };
});
function videoById(id){return VIDEOS.find(v=>v.id===id) || state.apiVideoCache[id];}
function channelVideos(cid){return VIDEOS.filter(v=>v.channelId===cid);}

const COMMENTERS=['Rae Solis','Kip Aoyama','Marlo Ives','Theo Braun','Yuki Sanders','Priya N.','Devon Blake','Wren Castillo','Omar Fajardo','Nadia Lund'];
const COMMENT_TEXT=[
"This is exactly the breakdown I needed, thank you.",
"Didn't expect that turn at the end — well done.",
"Been following since the first upload, quality keeps climbing.",
"Can we get a part two on this? So much more to unpack.",
"Underrated channel, algorithm needs to catch up.",
"Watched this twice already, saving for later too.",
"The pacing on this one is perfect.",
"Anyone else came here from a friend's recommendation?",
"Solid work as always, subscribed.",
"This deserves way more views."
];
function genComments(vid){
  const n=(hash(vid+'c')%4)+2;
  const arr=[];
  for(let i=0;i<n;i++){
    const seed=vid+'c'+i;
    arr.push({
      id:uid(),
      author:COMMENTERS[hash(seed)%COMMENTERS.length],
      avatar:personUrl(seed),
      text:COMMENT_TEXT[hash(seed+'t')%COMMENT_TEXT.length],
      likes:seedNum(seed+'lk',0,4200),
      ts:Date.now()-seedNum(seed+'ts',3600,60*60*24*300)*1000,
      liked:false,
      replies:[]
    });
  }
  return arr;
}

/* ---------------------------------- STATE (in-memory only) ---------------------------------- */
const state = {
  theme: matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark',
  route: {path:'/home',query:{}},
  user: null,
  apiKey: 'AIzaSyD6Jzauui_WJyEnrHKuAkkYUJ1mIGslX7I',
  useApi: true,
  region: 'US',
  autoplay: true,
  sidebarCollapsed: false,
  sidebarOpenMobile: false,
  subscriptions: new Set(['pulsewave','orbitalarcade','quanta']),
  likes: new Map(),           // videoId -> 1 | -1
  favorites: new Set(),
  watchLater: new Set(),
  history: [],                 // {videoId, ts}
  playlists: [
    {id:'pl_watchlater', name:'Watch later', system:true, videoIds:[]},
    {id:'pl1', name:'Late Night Focus', system:false, videoIds:['v2','v7','v37']}
  ],
  comments: new Map(),
  notifications: [],
  apiVideoCache: {},
  searchHistory: [],
};
function ensureComments(vid){ if(!state.comments.has(vid)) state.comments.set(vid, genComments(vid)); return state.comments.get(vid); }

/* ---------------------------------- SUPABASE (real auth + real data) ---------------------------------- */
const SUPABASE_URL = 'https://cpcyixyvzlmpkdmwlpef.supabase.co';
const SUPABASE_KEY = 'sb_publishable_P2vzvdJYdlM0IECfr1DwGw_e_k4z9PQ';
const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

function stateSnapshot(){
  return {
    likes:[...state.likes.entries()],
    favorites:[...state.favorites],
    watchLater:[...state.watchLater],
    history:state.history,
    playlists:state.playlists,
    subscriptions:[...state.subscriptions],
    searchHistory:state.searchHistory,
    autoplay:state.autoplay,
    region:state.region,
  };
}
function applySnapshot(d){
  if(!d) return;
  state.likes = new Map(d.likes||[]);
  state.favorites = new Set(d.favorites||[]);
  state.watchLater = new Set(d.watchLater||[]);
  state.history = d.history||[];
  state.playlists = (d.playlists&&d.playlists.length) ? d.playlists : state.playlists;
  state.subscriptions = new Set(d.subscriptions||['pulsewave','orbitalarcade','quanta']);
  state.searchHistory = d.searchHistory||[];
  state.autoplay = d.autoplay!==undefined ? d.autoplay : true;
  state.region = d.region||'US';
}

let persistTimer=null;
function schedulePersist(){
  if(!state.user || !state.user.id) return;
  clearTimeout(persistTimer);
  persistTimer = setTimeout(saveUserData, 700);
}
async function saveUserData(){
  if(!state.user || !state.user.id) return;
  try{
    await sb.from('user_data').upsert({ user_id: state.user.id, data: stateSnapshot(), updated_at: new Date().toISOString() });
  }catch(err){ console.error('Save failed', err); }
}
async function loadUserData(){
  try{
    const { data, error } = await sb.from('user_data').select('data').eq('user_id', state.user.id).maybeSingle();
    if(!error && data) applySnapshot(data.data);
  }catch(err){ console.error('Load failed', err); }
}
async function loadCommentsFromDB(vid){
  try{
    const { data, error } = await sb.from('comments').select('*').eq('video_id', vid).order('created_at', {ascending:false});
    if(error || !data) return null;
    const top = data.filter(c=>!c.parent_id).map(c=>({
      id:c.id, author:c.author, avatar:c.avatar, text:c.text, likes:c.likes||0, ts:new Date(c.created_at).getTime(), liked:false,
      replies:data.filter(r=>r.parent_id===c.id).map(r=>({author:r.author, avatar:r.avatar, text:r.text, ts:new Date(r.created_at).getTime()}))
    }));
    return top;
  }catch(err){ console.error('Comment load failed', err); return null; }
}
async function saveCommentToDB(vid, comment, parentId){
  try{
    const { data, error } = await sb.from('comments').insert({
      video_id:vid, author:comment.author, avatar:comment.avatar, text:comment.text, parent_id:parentId||null
    }).select().maybeSingle();
    if(!error && data && !parentId) comment.id = data.id;
  }catch(err){ console.error('Comment save failed', err); }
}

async function realSignUp(email,password,name){
  const { data, error } = await sb.auth.signUp({ email, password, options:{ data:{ name } } });
  if(error) throw error;
  return data;
}
async function realSignIn(email,password){
  const { data, error } = await sb.auth.signInWithPassword({ email, password });
  if(error) throw error;
  return data;
}
async function realSignOut(){
  await sb.auth.signOut();
}
function userFromSession(session){
  if(!session || !session.user) return null;
  const u=session.user;
  const name = u.user_metadata?.name || u.email.split('@')[0];
  return { id:u.id, name, handle:'@'+name.toLowerCase().replace(/[^a-z0-9]/g,''), avatar:personUrl(u.id), email:u.email };
}
async function initSupabaseAuth(){
  const { data:{ session } } = await sb.auth.getSession();
  if(session){
    state.user = userFromSession(session);
    await loadUserData();
    renderTopbar();
    if(state.route.path==='/settings') viewSettings();
  }
  sb.auth.onAuthStateChange((event, session)=>{
    if(event==='SIGNED_IN' && session){
      state.user = userFromSession(session);
      loadUserData().then(()=>{ renderTopbar(); route(); });
    } else if(event==='SIGNED_OUT'){
      state.user = null; renderTopbar();
    }
  });
}

function seedNotifications(){
  const subs=[...state.subscriptions];
  state.notifications = subs.slice(0,6).map((cid,i)=>{
    const vids=channelVideos(cid);
    const v=vids[i%Math.max(vids.length,1)] || VIDEOS[i];
    return {id:uid(),channelId:cid,videoId:v?v.id:VIDEOS[0].id,unread:i<3,ts:Date.now()-seedNum(cid+i,3600,90000)*1000};
  });
}
seedNotifications();

/* ---------------------------------- TOASTS ---------------------------------- */
function toast(msg,opts={}){
  const root=document.getElementById('toast-root');
  const el=document.createElement('div');
  el.className='toast'+(opts.err?' err':'');
  el.innerHTML=(opts.err?ic('warn',15):ic('check',15))+`<span>${esc(msg)}</span>`;
  root.appendChild(el);
  setTimeout(()=>{el.style.opacity='0';el.style.transition='opacity .3s';setTimeout(()=>el.remove(),300);},2400);
}

/* ---------------------------------- YOUTUBE DATA API v3 ---------------------------------- */
const YT_BASE='https://www.googleapis.com/youtube/v3';
async function ytFetch(endpoint,params){
  const url=new URL(YT_BASE+'/'+endpoint);
  Object.entries(params).forEach(([k,v])=>url.searchParams.set(k,v));
  url.searchParams.set('key',state.apiKey);
  const res=await fetch(url.toString());
  const data=await res.json();
  if(data.error) throw new Error(data.error.message || 'YouTube API request failed');
  return data;
}
function normalizeSearchItem(item){
  const vid = item.id.videoId;
  return {
    id:'yt_'+vid, ytId:vid, source:'api',
    title:item.snippet.title.replace(/&amp;/g,'&'),
    channelId:'yt_'+item.snippet.channelId,
    channelTitle:item.snippet.channelTitle,
    thumb:item.snippet.thumbnails?.high?.url || item.snippet.thumbnails?.medium?.url,
    description:item.snippet.description||'',
    daysAgo: Math.max(1, Math.floor((Date.now()-new Date(item.snippet.publishedAt).getTime())/86400000)),
    views:null, likesCount:null, dislikesCount:0, duration:0, live:item.snippet.liveBroadcastContent==='live',
    category:'live', tags:[]
  };
}
function normalizeVideoItem(item){
  const dur = isoToSeconds(item.contentDetails?.duration||'PT0S');
  return {
    id:'yt_'+item.id, ytId:item.id, source:'api',
    title:item.snippet.title.replace(/&amp;/g,'&'),
    channelId:'yt_'+item.snippet.channelId,
    channelTitle:item.snippet.channelTitle,
    thumb:item.snippet.thumbnails?.high?.url || item.snippet.thumbnails?.medium?.url,
    description:item.snippet.description||'',
    daysAgo: Math.max(1, Math.floor((Date.now()-new Date(item.snippet.publishedAt).getTime())/86400000)),
    views:Number(item.statistics?.viewCount||0),
    likesCount:Number(item.statistics?.likeCount||0),
    dislikesCount:0, duration:dur, live:item.snippet.liveBroadcastContent==='live',
    category:'live', tags:item.snippet.tags||[]
  };
}
function isoToSeconds(iso){
  const m=iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if(!m)return 0;
  return (parseInt(m[1]||0)*3600)+(parseInt(m[2]||0)*60)+parseInt(m[3]||0);
}
async function apiSearch(q){
  const data=await ytFetch('search',{part:'snippet',type:'video',maxResults:24,q});
  const items=data.items.map(normalizeSearchItem);
  items.forEach(v=>state.apiVideoCache[v.id]=v);
  return items;
}
async function apiTrending(){
  const data=await ytFetch('videos',{part:'snippet,statistics,contentDetails',chart:'mostPopular',maxResults:25,regionCode:state.region});
  const items=data.items.map(normalizeVideoItem);
  items.forEach(v=>state.apiVideoCache[v.id]=v);
  return items;
}
async function apiVideoDetails(ytId){
  const data=await ytFetch('videos',{part:'snippet,statistics,contentDetails',id:ytId});
  if(!data.items.length) throw new Error('Video not found');
  const v=normalizeVideoItem(data.items[0]);
  state.apiVideoCache[v.id]=v;
  return v;
}
async function apiChannel(channelId){
  const data=await ytFetch('channels',{part:'snippet,statistics',id:channelId});
  if(!data.items.length) throw new Error('Channel not found');
  const c=data.items[0];
  return {
    id:'yt_'+c.id, name:c.snippet.title, handle:'@'+c.snippet.title.toLowerCase().replace(/\s+/g,''),
    desc:c.snippet.description, avatar:c.snippet.thumbnails?.high?.url, banner:null,
    subs:Number(c.statistics?.subscriberCount||0)
  };
}
async function apiChannelVideos(channelId){
  const data=await ytFetch('search',{part:'snippet',channelId,type:'video',order:'date',maxResults:18});
  const items=data.items.map(normalizeSearchItem);
  items.forEach(v=>state.apiVideoCache[v.id]=v);
  return items;
}

/* ---------------------------------- PLAYER CONTROLLER ---------------------------------- */
function ensureYT(){
  return new Promise((resolve)=>{
    if(window.YT && window.YT.Player){resolve();return;}
    const prev=window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady=()=>{ if(prev)prev(); resolve(); };
    if(!document.getElementById('yt-iframe-api')){
      const tag=document.createElement('script'); tag.id='yt-iframe-api'; tag.src='https://www.youtube.com/iframe_api';
      document.head.appendChild(tag);
    }
  });
}
class PlayerController{
  constructor(mount){this.mount=mount;this.backend=null;this.type=null;this.pollId=null;this.listeners={};this.ready=false;}
  async load(video){
    this.destroy();
    this.video=video; this.ready=false;
    if(video.source==='api'){
      this.type='yt';
      await ensureYT();
      const div=document.createElement('div');
      this.mount.innerHTML=''; this.mount.appendChild(div);
      this.backend=new YT.Player(div,{
        videoId:video.ytId, width:'100%',height:'100%',
        playerVars:{controls:0,disablekb:1,modestbranding:1,rel:0,playsinline:1,iv_load_policy:3,fs:0},
        events:{
          onReady:()=>{this.ready=true;this._emit('ready');this._startPoll();this.play();},
          onStateChange:(e)=>{ if(e.data===0)this._emit('ended'); if(e.data===1)this._emit('play'); if(e.data===2)this._emit('pause');},
          onError:()=>this._emit('error')
        }
      });
    }else{
      this.type='html5';
      const v=document.createElement('video');
      v.src=video.file; v.playsInline=true; v.autoplay=true; v.className='native-video';
      this.mount.innerHTML=''; this.mount.appendChild(v); this.backend=v;
      v.addEventListener('loadedmetadata',()=>{this.ready=true;this._emit('ready');this._startPoll();});
      v.addEventListener('play',()=>this._emit('play'));
      v.addEventListener('pause',()=>this._emit('pause'));
      v.addEventListener('ended',()=>this._emit('ended'));
      v.addEventListener('error',()=>this._emit('error'));
    }
  }
  _startPoll(){clearInterval(this.pollId);this.pollId=setInterval(()=>this._emit('tick'),250);}
  play(){try{this.type==='yt'?this.backend.playVideo():this.backend.play();}catch(e){}}
  pause(){try{this.type==='yt'?this.backend.pauseVideo():this.backend.pause();}catch(e){}}
  toggle(){this.isPaused()?this.play():this.pause();}
  isPaused(){try{return this.type==='yt'?(this.backend.getPlayerState()!==1):this.backend.paused;}catch(e){return true;}}
  seek(t){try{this.type==='yt'?this.backend.seekTo(t,true):(this.backend.currentTime=t);}catch(e){}}
  getCurrentTime(){try{return this.type==='yt'?this.backend.getCurrentTime():this.backend.currentTime;}catch(e){return 0;}}
  getDuration(){try{return this.type==='yt'?this.backend.getDuration():this.backend.duration||0;}catch(e){return 0;}}
  setVolume(v){try{this.type==='yt'?this.backend.setVolume(v*100):(this.backend.volume=v);}catch(e){}}
  setMuted(m){try{if(this.type==='yt'){m?this.backend.mute():this.backend.unMute();}else{this.backend.muted=m;}}catch(e){}}
  setRate(r){try{this.type==='yt'?this.backend.setPlaybackRate(r):(this.backend.playbackRate=r);}catch(e){}}
  on(evt,cb){(this.listeners[evt]=this.listeners[evt]||[]).push(cb);}
  _emit(evt,p){(this.listeners[evt]||[]).forEach(cb=>cb(p));}
  destroy(){clearInterval(this.pollId);this.pollId=null;
    if(this.type==='yt'&&this.backend&&this.backend.destroy){try{this.backend.destroy();}catch(e){}}
    this.backend=null;this.type=null;
  }
}
let player=null;

/* ---------------------------------- RENDER: SIDEBAR / TOPBAR / MOBILE NAV ---------------------------------- */
function channelDisplay(v){
  if(v.source==='api') return {name:v.channelTitle, avatar:'https://ui-avatars.com/api/?background=161924&color=00E5FF&name='+encodeURIComponent(v.channelTitle||'YT'), id:v.channelId};
  const c=CHANNELS[v.channelId]; return {name:c.name, avatar:c.avatar, id:c.id};
}
function primaryNav(){
  const items=[
    ['home','home','Home'],['trending','compass','Trending'],['subscriptions','users','Subscriptions']
  ];
  return items.map(([route,icon,label])=>navItem(route,icon,label)).join('');
}
function navItem(route,icon,label,meta){
  const active = state.route.path==='/'+route || (route==='home'&&state.route.path==='/home');
  return `<div class="nav-item ${active?'active':''}" data-action="nav" data-route="/${route}">${ic(icon,20)}<span class="nav-label">${label}</span>${meta?`<span class="nav-meta">${meta}</span>`:''}</div>`;
}
function renderSidebar(){
  const sub = [...state.subscriptions].slice(0,8).map(cid=>{
    const c=CHANNELS[cid]; if(!c)return '';
    return `<div class="nav-item" data-action="nav" data-route="/channel/${cid}"><img class="sub-avatar" src="${c.avatar}" alt=""><span class="nav-label">${esc(c.name)}</span></div>`;
  }).join('');
  const libItems=[
    ['history','history','History'],['watchlater','clock','Watch later'],['liked','thumbUp','Liked videos'],
    ['favorites','star','Favorites'],['playlists','list','Playlists']
  ];
  document.getElementById('sidebar').innerHTML = `
    <div class="side-logo">
      <div class="brand">${logoSvg(30)}<span>Nex<em>Vibe</em></span></div>
      <button class="icon-btn hide-mobile" data-action="toggle-sidebar-desktop">${ic('menu',18)}</button>
    </div>
    ${primaryNav()}
    <div class="side-heading">Library</div>
    ${libItems.map(([r,i,l])=>navItem(r,i,l)).join('')}
    ${sub?`<hr><div class="side-heading">Subscriptions</div>${sub}`:''}
    <hr>
    ${navItem('settings','settings','Settings')}
    <div class="sidebar-foot">NexVibe · demo build<br>Data resets on reload.</div>
  `;
  document.getElementById('sidebar').classList.toggle('collapsed', state.sidebarCollapsed);
  document.getElementById('sidebar').classList.toggle('open', state.sidebarOpenMobile);
  document.getElementById('scrim').classList.toggle('show', state.sidebarOpenMobile);
}
function logoSvg(size){
  return `<span class="logo-mark" style="width:${size}px;height:${size}px"><svg viewBox="0 0 100 100">
    <circle cx="50" cy="50" r="46" fill="none" stroke="var(--cyan)" stroke-width="3" opacity=".55" class="ring"/>
    <circle cx="50" cy="50" r="34" fill="none" stroke="var(--border)" stroke-width="2"/>
    <path d="M38 30 L72 50 L38 70 Z" fill="var(--orange)"/>
  </svg></span>`;
}
function renderMobileNav(){
  const items=[['home','home','Home'],['trending','compass','Trending'],['search','search','Search'],
    ['subscriptions','users','Subs'],['settings','settings','More']];
  document.getElementById('mobileNav').innerHTML=`<ul>${items.map(([r,i,l])=>{
    const active=state.route.path==='/'+r||(r==='home'&&state.route.path==='/home');
    return `<li class="nav-item ${active?'active':''}" data-action="${r==='search'?'focus-search':'nav'}" data-route="/${r}">${ic(i,20)}<span>${l}</span></li>`;
  }).join('')}</ul>`;
}
function renderTopbar(){
  const unread=state.notifications.filter(n=>n.unread).length;
  document.getElementById('topbar').innerHTML = `
    <button class="icon-btn hide-desktop" data-action="toggle-sidebar-mobile">${ic('menu',20)}</button>
    <div class="brand hide-mobile" style="cursor:pointer" data-action="nav" data-route="/home">${logoSvg(28)}<span>Nex<em>Vibe</em></span></div>
    <div class="searchbar rel">
      <form data-action="submit-search" autocomplete="off">
        <input id="searchInput" type="text" placeholder="Search NexVibe" value="${esc(state.route.query.q||'')}">
        <button type="submit">${ic('search',18)}</button>
      </form>
      <div class="search-suggest" id="searchSuggest"></div>
    </div>
    <div class="topbar-right">
      <button class="theme-switch hide-mobile" data-action="toggle-theme" title="Toggle theme">
        <span class="knob">${state.theme==='dark'?ic('moon',12):ic('sun',12)}</span>
      </button>
      <div class="rel">
        <button class="icon-btn" data-action="toggle-notifications">${ic('bell',20)}${unread?`<span class="badge-dot">${unread}</span>`:''}</button>
      </div>
      ${state.user ? `
      <div class="rel">
        <button class="avatar-btn" data-action="toggle-account"><img src="${state.user.avatar}" alt=""></button>
      </div>` : `<button class="btn btn-primary btn-sm" data-action="open-signin">${ic('user',15)}<span class="hide-mobile">Sign in</span></button>`}
    </div>
  `;
}
function renderChrome(){renderSidebar();renderTopbar();renderMobileNav();}

/* ---------------------------------- CARDS / COMPONENTS ---------------------------------- */
function skeletonGrid(n=12,compact=false){
  return `<div class="grid ${compact?'compact':''}">${Array.from({length:n}).map(()=>`
    <div>
      <div class="thumb-wrap skeleton" style="aspect-ratio:16/9"></div>
      <div class="vcard-body">
        <div class="skeleton" style="width:36px;height:36px;border-radius:50%;flex:0 0 auto"></div>
        <div style="flex:1">
          <div class="skeleton" style="height:13px;border-radius:4px;margin-bottom:8px"></div>
          <div class="skeleton" style="height:11px;width:70%;border-radius:4px"></div>
        </div>
      </div>
    </div>`).join('')}</div>`;
}
function videoCard(v){
  const ch=channelDisplay(v);
  const views = v.views==null ? '—' : fmtViews(v.views)+' views';
  return `<div class="vcard fade-up" data-action="nav" data-route="/watch" data-query="v=${v.id}">
    <div class="thumb-wrap">
      <img src="${v.thumb}" alt="" loading="lazy">
      <div class="thumb-scan"></div>
      ${v.live?`<span class="live-badge">LIVE</span>`:`<span class="duration-badge">${v.duration?fmtDur(v.duration):''}</span>`}
    </div>
    <div class="vcard-body">
      <span class="ch-ring" data-action="nav" data-route="/channel/${ch.id}" data-stop="1"><img src="${ch.avatar}" alt=""></span>
      <div style="min-width:0;flex:1">
        <div class="vcard-title">${esc(v.title)}</div>
        <div class="vcard-meta">
          <span data-action="nav" data-route="/channel/${ch.id}" data-stop="1">${esc(ch.name)}</span><br>
          ${views} ${v.daysAgo?'· '+fmtAgo(v.daysAgo):''}
        </div>
      </div>
      <button class="vcard-kebab" data-action="open-save-menu" data-video="${v.id}" data-stop="1">${ic('dots',17)}</button>
    </div>
  </div>`;
}
function resultRow(v){
  const ch=channelDisplay(v);
  return `<div class="result-row" data-action="nav" data-route="/watch" data-query="v=${v.id}">
    <div class="thumb-wrap">
      <img src="${v.thumb}" alt="" loading="lazy"><div class="thumb-scan"></div>
      ${v.live?`<span class="live-badge">LIVE</span>`:`<span class="duration-badge">${v.duration?fmtDur(v.duration):''}</span>`}
    </div>
    <div class="result-info">
      <h3>${esc(v.title)}</h3>
      <div class="r-meta">${v.views==null?'':fmtViews(v.views)+' views · '}${fmtAgo(v.daysAgo)}</div>
      <div class="r-channel"><img src="${ch.avatar}" alt="">${esc(ch.name)}</div>
      <p>${esc(v.description||'')}</p>
    </div>
  </div>`;
}
function upNextItem(v){
  const ch=channelDisplay(v);
  return `<div class="up-item" data-action="nav" data-route="/watch" data-query="v=${v.id}">
    <div class="thumb-wrap"><img src="${v.thumb}" alt=""><div class="thumb-scan"></div>
      ${v.live?`<span class="live-badge">LIVE</span>`:`<span class="duration-badge">${v.duration?fmtDur(v.duration):''}</span>`}</div>
    <div><div class="u-title">${esc(v.title)}</div><div class="u-meta">${esc(ch.name)}<br>${v.views==null?'':fmtViews(v.views)+' views'}</div></div>
  </div>`;
}
function emptyState(icon,title,desc,actionHtml){
  return `<div class="state-block fade-up"><div class="state-icon">${ic(icon,28)}</div><h3>${esc(title)}</h3><p>${esc(desc)}</p>${actionHtml||''}</div>`;
}
function errorBanner(msg,retryAction){
  return `<div class="error-banner">${ic('warn',20)}<div class="msg"><b>Something didn't load.</b> ${esc(msg)}</div>
    ${retryAction?`<button class="btn btn-ghost btn-sm" data-action="${retryAction}">${ic('refresh',14)}Retry</button>`:''}</div>`;
}

/* ---------------------------------- ROUTER ---------------------------------- */
const routes = {
  '/home': viewHome, '/trending': viewTrending, '/search': viewSearch, '/watch': viewWatch,
  '/channel': viewChannel, '/subscriptions': viewSubscriptions, '/history': viewHistory,
  '/watchlater': viewWatchLater, '/liked': viewLiked, '/favorites': viewFavorites,
  '/playlists': viewPlaylists, '/playlist': viewPlaylistDetail, '/settings': viewSettings
};
function parseHash(){
  let h = location.hash.slice(1) || '/home';
  let [path, qs] = h.split('?');
  const parts = path.split('/').filter(Boolean);
  let base = '/'+(parts[0]||'home');
  let param = parts[1]||null;
  const query={};
  if(qs) qs.split('&').forEach(pair=>{const [k,v]=pair.split('=');if(k)query[decodeURIComponent(k)]=decodeURIComponent(v||'');});
  return {path:base, param, query};
}
async function route(){
  const r=parseHash();
  state.route={path:r.path,query:r.query,param:r.param};
  state.sidebarOpenMobile=false;
  renderChrome();
  window.scrollTo({top:0,behavior:'instant'});
  const view=document.getElementById('view');
  const fn = routes[r.path] || viewHome;
  try{
    await fn(r);
  }catch(e){
    console.error(e);
    view.innerHTML = errorBanner(e.message||'Unexpected error.', null);
  }
}
window.addEventListener('hashchange', route);

/* ---------------------------------- VIEWS ---------------------------------- */
async function viewHome(r){
  const view=document.getElementById('view');
  const cat = r.query.cat || 'all';
  view.innerHTML = `
    <div class="chip-row" id="catChips">${CATEGORIES.map(c=>`<button class="chip ${c.key===cat?'active':''}" data-action="set-cat" data-cat="${c.key}">${c.label}</button>`).join('')}</div>
    <div id="homeBody">${skeletonGrid(12)}</div>
  `;
  await delay(400);
  const body=document.getElementById('homeBody');
  if(cat!=='all'){
    const list = VIDEOS.filter(v=>v.category===cat);
    body.innerHTML = list.length ? `<div class="grid">${list.map(videoCard).join('')}</div>`
      : emptyState('compass','Nothing here yet','No videos found in this category right now.');
    return;
  }
  let liveNote='';
  const recommended = pickRecommended();
  const trendingTop = [...VIDEOS].sort((a,b)=>b.views-a.views).slice(0,8);
  const subVideos = VIDEOS.filter(v=>state.subscriptions.has(v.channelId)).slice(0,8);
  const lastWatchedCat = getLastWatchedCategory();
  const becauseYouWatched = lastWatchedCat ? VIDEOS.filter(v=>v.category===lastWatchedCat.cat && v.id!==lastWatchedCat.videoId).slice(0,8) : [];

  let apiRail='';
  if(state.useApi && state.apiKey){
    try{
      const items = await apiTrending();
      apiRail = `<div class="rail"><div class="rail-head"><h3>${ic('globe',18)} Live from YouTube</h3></div>
        <div class="grid">${items.slice(0,8).map(videoCard).join('')}</div></div>`;
    }catch(e){
      apiRail = errorBanner('Live YouTube data failed to load ('+e.message+'). Showing demo content instead.', null);
    }
  }

  body.innerHTML = `
    ${apiRail}
    <div class="rail"><div class="rail-head"><h3>Recommended for you</h3></div><div class="grid">${recommended.map(videoCard).join('')}</div></div>
    ${becauseYouWatched.length?`<div class="rail"><div class="rail-head"><h3>Because you watched ${lastWatchedCat.cat}</h3></div><div class="grid">${becauseYouWatched.map(videoCard).join('')}</div></div>`:''}
    ${subVideos.length?`<div class="rail"><div class="rail-head"><h3>New from your subscriptions</h3><a class="see-all" data-action="nav" data-route="/subscriptions">See all</a></div><div class="grid">${subVideos.map(videoCard).join('')}</div></div>`:''}
    <div class="rail"><div class="rail-head"><h3>Trending now</h3><a class="see-all" data-action="nav" data-route="/trending">See all</a></div><div class="grid">${trendingTop.map(videoCard).join('')}</div></div>
  `;
}
function pickRecommended(){
  const shuffled=[...VIDEOS].sort((a,b)=>hash(a.id+'r')-hash(b.id+'r'));
  return shuffled.slice(0,16);
}
function getLastWatchedCategory(){
  if(!state.history.length) return null;
  const last=state.history[0];
  const v=videoById(last.videoId);
  if(!v) return null;
  return {cat:v.category, videoId:v.id};
}

async function viewTrending(r){
  const view=document.getElementById('view');
  const tab = r.query.tab || 'now';
  const tabs=[['now','Now'],['music','Music'],['gaming','Gaming'],['movies','Movies'],['news','News']];
  view.innerHTML = `
    <div class="view-header"><div><span class="eyebrow">Ranked</span><h1 class="view-title">${ic('compass',22)} Trending</h1></div></div>
    <div class="chip-row">${tabs.map(([k,l])=>`<button class="chip ${k===tab?'active':''}" data-action="set-trend-tab" data-tab="${k}">${l}</button>`).join('')}</div>
    <div id="trendBody">${skeletonGrid(8)}</div>
  `;
  await delay(350);
  let list = tab==='now' ? [...VIDEOS] : VIDEOS.filter(v=>v.category===tab);
  list = list.sort((a,b)=>b.views-a.views).slice(0,20);
  document.getElementById('trendBody').innerHTML = list.length ? list.map((v,i)=>{
    const ch=channelDisplay(v);
    return `<div class="trend-row" data-action="nav" data-route="/watch" data-query="v=${v.id}">
      <div class="trend-num">${String(i+1).padStart(2,'0')}</div>
      <div class="thumb-wrap"><img src="${v.thumb}" alt=""><div class="thumb-scan"></div><span class="duration-badge">${fmtDur(v.duration)}</span></div>
      <div class="result-info"><h3 style="margin:0 0 6px;font-size:15px">${esc(v.title)}</h3>
        <div class="r-channel"><img src="${ch.avatar}">${esc(ch.name)}</div>
        <div class="r-meta">${fmtViews(v.views)} views · ${fmtAgo(v.daysAgo)}</div></div>
    </div>`;
  }).join('') : emptyState('compass','No trending videos','Nothing trending in this category right now.');
}

async function viewSearch(r){
  const view=document.getElementById('view');
  const q=r.query.q||'';
  if(!q){ view.innerHTML=emptyState('search','Search NexVibe','Type something in the search bar to find videos, channels and more.'); return; }
  view.innerHTML = `
    <div class="view-header"><div><span class="eyebrow">Results</span><h1 class="view-title">"${esc(q)}"</h1></div></div>
    <div id="searchBody">${skeletonGrid(6)}</div>
  `;
  await delay(350);
  const body=document.getElementById('searchBody');

  if(state.useApi && state.apiKey){
    try{
      const items=await apiSearch(q);
      body.innerHTML = items.length ? items.map(resultRow).join('') : emptyState('search','No results found',`Nothing matched "${q}" on YouTube. Try different keywords.`);
      return;
    }catch(e){
      body.innerHTML = errorBanner(e.message, 'retry-search') + skeletonGrid(0);
      body.innerHTML += mockSearchResults(q);
      return;
    }
  }
  body.innerHTML = mockSearchResults(q);
}
function mockSearchResults(q){
  const ql=q.toLowerCase();
  const list=VIDEOS.filter(v=> v.title.toLowerCase().includes(ql) || v.category.includes(ql) || CHANNELS[v.channelId].name.toLowerCase().includes(ql) || v.tags.some(t=>t.toLowerCase().includes(ql)));
  return list.length ? list.map(resultRow).join('') : emptyState('search','No results found',`Nothing matched "${q}" in demo content. Try "tech", "music", or a channel name.`);
}

async function viewWatch(r){
  const id=r.query.v;
  const view=document.getElementById('view');
  if(!id){view.innerHTML=emptyState('film','No video selected','Pick a video from Home to start watching.');return;}
  view.innerHTML = `<div class="watch-layout">
    <div>
      <div class="player-shell paused" id="playerShell">
        <div class="player-loading" id="playerLoading"><div class="sonar"><span></span><span></span><span></span></div></div>
        <div class="mount" id="playerMount"></div>
      </div>
      <div id="watchMeta"></div>
    </div>
    <div class="up-next" id="upNext"><div class="skeleton" style="height:20px;width:120px;border-radius:4px;margin-bottom:16px"></div>${skeletonGrid(0)}</div>
  </div>`;

  let video = videoById(id);
  if(!video && id.startsWith('yt_') && state.apiKey){
    try{ video = await apiVideoDetails(id.replace('yt_','')); }catch(e){}
  }
  if(!video){
    document.getElementById('watchMeta').innerHTML = errorBanner('This video could not be found. It may have been removed.', null);
    document.getElementById('playerLoading').style.display='none';
    return;
  }
  logHistory(video.id);
  initPlayer(video);
  renderWatchMeta(video);
  renderUpNext(video);
  refreshCommentsFromDB(video.id);
}
async function refreshCommentsFromDB(vid){
  const real = await loadCommentsFromDB(vid);
  if(real){
    state.comments.set(vid, real.length ? real : ensureComments(vid));
    const list=document.getElementById('commentsList');
    const head=document.querySelector('.comments-head h3');
    if(list && state.route.query.v===vid){ list.innerHTML = state.comments.get(vid).map(c=>commentItem(c,vid)).join(''); }
    if(head && state.route.query.v===vid){ head.textContent = state.comments.get(vid).length+' Comments'; }
  }
}
function delay(ms){return new Promise(res=>setTimeout(res,ms));}
function logHistory(vid){
  state.history = state.history.filter(h=>h.videoId!==vid);
  state.history.unshift({videoId:vid, ts:Date.now()});
  if(state.history.length>200) state.history.pop();
}
function initPlayer(video){
  const shell=document.getElementById('playerShell');
  const mount=document.getElementById('playerMount');
  const loading=document.getElementById('playerLoading');
  player = new PlayerController(mount);
  let dragging=false, rate=1;
  const controlsHtml = `
    <div class="player-overlay-top">${esc(video.title)}</div>
    <div class="player-badge">${video.source==='api'?'YOUTUBE':'NEXVIBE PLAYER'}</div>
    <button class="player-center-btn" data-action="player-toggle">${ic('play',26)}</button>
    <div class="player-controls">
      <div class="seek-row">
        <input type="range" class="seek-bar" id="seekBar" min="0" max="100" value="0" step="0.1">
      </div>
      <div class="ctrl-row">
        <button class="icon-btn" data-action="player-toggle" id="playBtn">${ic('pause',18)}</button>
        <div class="vol-row">
          <button class="icon-btn" data-action="player-mute" id="muteBtn">${ic('volume',17)}</button>
          <input type="range" class="vol-bar" id="volBar" min="0" max="1" step="0.05" value="1">
        </div>
        <span class="time-lbl" id="timeLbl">0:00 / 0:00</span>
        <span class="spacer"></span>
        <div class="speed-menu">
          <button class="speed-btn" data-action="toggle-speed" id="speedBtn">1x</button>
          <div class="speed-pop" id="speedPop">${[0.5,0.75,1,1.25,1.5,2].map(s=>`<button data-action="set-speed" data-rate="${s}" class="${s===1?'active':''}">${s}x</button>`).join('')}</div>
        </div>
        <button class="icon-btn" data-action="player-fullscreen">${ic('fullscreen',17)}</button>
      </div>
    </div>
  `;
  shell.insertAdjacentHTML('beforeend', controlsHtml);
  player.load(video);
  player.on('ready', ()=>{ loading.style.display='none'; shell.classList.remove('paused'); });
  player.on('play', ()=>{ shell.classList.remove('paused'); document.getElementById('playBtn').innerHTML=ic('pause',18); shell.querySelector('.player-center-btn').innerHTML=ic('play',26); });
  player.on('pause', ()=>{ shell.classList.add('paused'); document.getElementById('playBtn').innerHTML=ic('play',18); });
  player.on('error', ()=>{ loading.innerHTML = `<div class="state-block" style="padding:20px"><div class="state-icon">${ic('warn',24)}</div><h3 style="color:#fff">Playback error</h3><p>This video couldn't be played. Try another one.</p></div>`; });
  player.on('ended', ()=>{
    if(state.autoplay){
      const list=relatedVideos(video);
      if(list[0]) location.hash='#/watch?v='+list[0].id;
    }
  });
  player.on('tick', ()=>{
    if(dragging) return;
    const cur=player.getCurrentTime(), dur=player.getDuration();
    const seek=document.getElementById('seekBar');
    if(seek && dur){ seek.max=dur; seek.value=cur; }
    const lbl=document.getElementById('timeLbl');
    if(lbl) lbl.textContent = fmtClock(cur)+' / '+fmtClock(dur);
  });
  setTimeout(()=>{
    const seek=document.getElementById('seekBar');
    if(seek){
      seek.addEventListener('input', ()=>{dragging=true;});
      seek.addEventListener('change', ()=>{player.seek(Number(seek.value)); dragging=false;});
    }
    const vol=document.getElementById('volBar');
    if(vol) vol.addEventListener('input', ()=>player.setVolume(Number(vol.value)));
  },0);
}
function relatedVideos(video){
  return VIDEOS.filter(v=>v.category===video.category && v.id!==video.id);
}
function renderWatchMeta(video){
  const ch=channelDisplay(video);
  const isSub = state.subscriptions.has(ch.id);
  const liked = state.likes.get(video.id);
  const isWL = state.watchLater.has(video.id);
  const isFav = state.favorites.has(video.id);
  const comments = ensureComments(video.id);
  document.getElementById('watchMeta').innerHTML = `
    <h1 class="watch-title">${esc(video.title)}</h1>
    <div class="watch-actions">
      <div class="channel-row">
        <img src="${ch.avatar}" data-action="nav" data-route="/channel/${ch.id}" alt="">
        <div>
          <div class="cn" data-action="nav" data-route="/channel/${ch.id}">${esc(ch.name)}</div>
          <div class="cn-subs">${fmtViews(CHANNELS[ch.id]?.subs || seedNum(ch.id,1000,900000))} subscribers</div>
        </div>
        ${video.source!=='api' ? `<button class="btn ${isSub?'btn-ghost':'btn-accent'} btn-sm" data-action="toggle-sub" data-channel="${ch.id}" style="margin-left:10px">${isSub?'Subscribed':'Subscribe'}</button>` : ''}
      </div>
      <div class="action-cluster">
        <div class="segmented">
          <button data-action="like" data-video="${video.id}" data-type="1" class="${liked===1?'on':''}">${ic('thumbUp',16)}<span>${fmtViews((video.likesCount||0)+(liked===1?1:0))}</span></button>
          <button data-action="like" data-video="${video.id}" data-type="-1" class="${liked===-1?'on dislike-on':''}">${ic('thumbDown',16)}</button>
        </div>
        <button class="btn btn-ghost btn-sm" data-action="open-share" data-video="${video.id}">${ic('share',15)}Share</button>
        <button class="btn btn-ghost btn-sm" data-action="toggle-watchlater" data-video="${video.id}">${ic(isWL?'check':'clock',15)}${isWL?'Saved':'Watch later'}</button>
        <button class="btn btn-ghost btn-sm" data-action="toggle-favorite" data-video="${video.id}">${ic('star',15)}${isFav?'Favorited':'Favorite'}</button>
        <button class="btn btn-ghost btn-sm" data-action="open-save-menu" data-video="${video.id}">${ic('plus',15)}Save</button>
      </div>
    </div>
    <div class="desc-box collapsed" id="descBox" data-action="toggle-desc">
      <div class="d-meta"><span>${video.views==null?'—':fmtViews(video.views)+' views'}</span><span>${fmtAgo(video.daysAgo)}</span></div>
      <p>${esc(video.description||'')}</p>
      ${video.tags&&video.tags.length?`<div style="margin-top:10px">${video.tags.map(t=>`<span class="tag-pill">#${esc(t)}</span>`).join('')}</div>`:''}
      <span class="more">Show more</span>
    </div>
    <div class="comments-head">
      <h3>${comments.length} Comments</h3>
      <div class="sort-select">${ic('chevDown',14)} Top comments</div>
    </div>
    <form class="comment-form" data-action="submit-comment" data-video="${video.id}">
      <img src="${state.user?state.user.avatar:personUrl('guest')}" alt="">
      <div class="cf-body">
        <textarea placeholder="Add a comment..." rows="1" id="commentInput"></textarea>
        <div class="cf-actions">
          <button type="button" class="btn btn-outline btn-sm" data-action="clear-comment">Cancel</button>
          <button type="submit" class="btn btn-primary btn-sm">Comment</button>
        </div>
      </div>
    </form>
    <div id="commentsList">${comments.map(c=>commentItem(c,video.id)).join('')}</div>
  `;
}
function commentItem(c,vid){
  return `<div class="comment-item" data-cid="${c.id}">
    <img src="${c.avatar}" alt="">
    <div style="flex:1">
      <div class="ci-head"><b>${esc(c.author)}</b><span>${timeAgoShort(c.ts)}</span></div>
      <p>${esc(c.text)}</p>
      <div class="ci-actions">
        <span class="cbtn ${c.liked?'on':''}" data-action="like-comment" data-video="${vid}" data-cid="${c.id}">${ic('thumbUp',14)} ${c.likes}</span>
        <span class="cbtn" data-action="reply-comment" data-video="${vid}" data-cid="${c.id}">${ic('reply',14)} Reply</span>
      </div>
      <div class="replies" id="replies-${c.id}">${(c.replies||[]).map(r=>`
        <div class="comment-item"><img src="${r.avatar}" alt=""><div style="flex:1">
          <div class="ci-head"><b>${esc(r.author)}</b><span>${timeAgoShort(r.ts)}</span></div><p>${esc(r.text)}</p></div></div>
      `).join('')}</div>
    </div>
  </div>`;
}
function renderUpNext(video){
  const related = relatedVideos(video).slice(0,12);
  document.getElementById('upNext').innerHTML = `
    <h4>Up next <div class="autoplay-toggle">Autoplay <div class="mini-switch ${state.autoplay?'on':''}" data-action="toggle-autoplay"><div class="k"></div></div></div></h4>
    ${related.length ? related.map(upNextItem).join('') : emptyState('compass','No related videos','Check back once more videos are available in this category.')}
  `;
}

async function viewChannel(r){
  const id=r.param;
  const view=document.getElementById('view');

  if(id==='me'){
    if(!state.user){ view.innerHTML=emptyState('user','Sign in required','Sign in to see your own channel page.'); return; }
    view.innerHTML = `<div class="skeleton" style="height:180px;border-radius:18px;margin-bottom:60px"></div>${skeletonGrid(8)}`;
    await delay(150);
    const likedVideos = [...state.likes.entries()].filter(([,v])=>v===1).map(([vid])=>videoById(vid)).filter(Boolean);
    const favVideos = [...state.favorites].map(vid=>videoById(vid)).filter(Boolean);
    const ownPlaylists = state.playlists.filter(p=>!p.system);
    const tab = r.query.tab || 'videos';
    view.innerHTML = `
      <div class="channel-banner" style="background-image:url(${bannerUrl(state.user.id)})"></div>
      <div class="channel-head">
        <img src="${state.user.avatar}" alt="">
        <div style="flex:1;min-width:200px">
          <h2>${esc(state.user.name)}</h2>
          <div class="ch-meta">${esc(state.user.handle)} · ${state.subscriptions.size} subscriptions · ${likedVideos.length} liked · ${ownPlaylists.length} playlists</div>
          <div class="ch-desc">Your personal NexVibe channel — this is what you've liked, favorited, and organized.</div>
        </div>
        <button class="btn btn-ghost" data-action="nav" data-route="/settings">${ic('settings',16)}Edit profile</button>
      </div>
      <div class="tab-row">
        <button class="${tab==='videos'?'active':''}" data-action="channel-tab" data-tab="videos" data-channel="me">Liked videos</button>
        <button class="${tab==='favorites'?'active':''}" data-action="channel-tab" data-tab="favorites" data-channel="me">Favorites</button>
        <button class="${tab==='playlists'?'active':''}" data-action="channel-tab" data-tab="playlists" data-channel="me">Playlists</button>
      </div>
      <div id="channelBody"></div>
    `;
    const body=document.getElementById('channelBody');
    if(tab==='favorites'){
      body.innerHTML = favVideos.length ? `<div class="grid">${favVideos.map(videoCard).join('')}</div>` : emptyState('heart','No favorites yet','Tap the heart on any video to save it here.');
    }else if(tab==='playlists'){
      body.innerHTML = ownPlaylists.length ? `<div class="grid compact">${ownPlaylists.map(playlistCard).join('')}</div>` : emptyState('list','No playlists yet','Create a playlist to organize your videos.');
    }else{
      body.innerHTML = likedVideos.length ? `<div class="grid">${likedVideos.map(videoCard).join('')}</div>` : emptyState('thumbUp','No liked videos yet','Videos you like will show up here.');
    }
    return;
  }

  view.innerHTML = `<div class="skeleton" style="height:180px;border-radius:18px;margin-bottom:60px"></div>${skeletonGrid(8)}`;
  await delay(300);

  let channel, videos, isApi=false;
  if(id && id.startsWith('yt_') && state.apiKey){
    isApi=true;
    try{
      channel = await apiChannel(id.replace('yt_',''));
      videos = await apiChannelVideos(id.replace('yt_',''));
    }catch(e){
      view.innerHTML = errorBanner(e.message, null);
      return;
    }
  }else{
    const c=CHANNELS[id];
    if(!c){ view.innerHTML=emptyState('users','Channel not found','This channel does not exist in NexVibe.'); return; }
    channel=c; videos=channelVideos(id);
  }
  const isSub = state.subscriptions.has(channel.id);
  const tab = r.query.tab || 'videos';
  view.innerHTML = `
    <div class="channel-banner" style="background-image:url(${channel.banner||bannerUrl(channel.id)})"></div>
    <div class="channel-head">
      <img src="${channel.avatar}" alt="">
      <div style="flex:1;min-width:200px">
        <h2>${esc(channel.name)}</h2>
        <div class="ch-meta">${esc(channel.handle||'')} · ${fmtViews(channel.subs)} subscribers · ${videos.length} videos</div>
        <div class="ch-desc">${esc(channel.desc||'')}</div>
      </div>
      ${!isApi ? `<button class="btn ${isSub?'btn-ghost':'btn-accent'}" data-action="toggle-sub" data-channel="${channel.id}">${isSub?'Subscribed':'Subscribe'}</button>` : ''}
    </div>
    <div class="tab-row">
      <button class="${tab==='videos'?'active':''}" data-action="channel-tab" data-tab="videos" data-channel="${channel.id}">Videos</button>
      <button class="${tab==='playlists'?'active':''}" data-action="channel-tab" data-tab="playlists" data-channel="${channel.id}">Playlists</button>
      <button class="${tab==='about'?'active':''}" data-action="channel-tab" data-tab="about" data-channel="${channel.id}">About</button>
    </div>
    <div id="channelBody"></div>
  `;
  const body=document.getElementById('channelBody');
  if(tab==='about'){
    body.innerHTML = `<div class="settings-card" style="max-width:640px"><h3>About ${esc(channel.name)}</h3><p style="color:var(--text-dim);font-size:13.5px;line-height:1.7;white-space:pre-line">${esc(channel.desc||'No description provided.')}</p></div>`;
  }else if(tab==='playlists'){
    const owned = state.playlists.filter(p=>!p.system);
    body.innerHTML = owned.length ? `<div class="grid compact">${owned.map(playlistCard).join('')}</div>` : emptyState('list','No playlists','This channel has not published any playlists.');
  }else{
    body.innerHTML = videos.length ? `<div class="grid">${videos.map(videoCard).join('')}</div>` : emptyState('film','No videos yet','This channel has not uploaded anything yet.');
  }
}

async function viewSubscriptions(){
  const view=document.getElementById('view');
  const subs=[...state.subscriptions];
  view.innerHTML = `<div class="view-header"><div><span class="eyebrow">Following</span><h1 class="view-title">${ic('users',22)} Subscriptions</h1></div></div>`;
  if(!subs.length){ view.innerHTML += emptyState('users','No subscriptions yet','Subscribe to channels to see their latest uploads here.'); return; }
  view.innerHTML += `<div class="chip-row">${subs.map(cid=>`<div class="chip" style="display:flex;align-items:center;gap:8px" data-action="nav" data-route="/channel/${cid}"><img src="${CHANNELS[cid].avatar}" style="width:18px;height:18px;border-radius:50%"> ${esc(CHANNELS[cid].name)}</div>`).join('')}</div>`;
  const vids = VIDEOS.filter(v=>subs.includes(v.channelId)).sort((a,b)=>a.daysAgo-b.daysAgo);
  view.innerHTML += vids.length ? `<div class="grid">${vids.map(videoCard).join('')}</div>` : emptyState('film','Nothing new','Your subscribed channels have not posted anything recently.');
}

async function viewHistory(){
  const view=document.getElementById('view');
  view.innerHTML = `<div class="view-header">
    <div><span class="eyebrow">Activity</span><h1 class="view-title">${ic('history',22)} Watch history</h1></div>
    ${state.history.length?`<button class="btn btn-outline btn-sm" data-action="clear-history">${ic('trash',15)}Clear all</button>`:''}
  </div>`;
  if(!state.history.length){ view.innerHTML+=emptyState('history','No watch history','Videos you watch will show up here.'); return; }
  const groups={};
  state.history.forEach(h=>{
    const d=new Date(h.ts); const key=d.toDateString()===new Date().toDateString()?'Today':d.toLocaleDateString(undefined,{month:'long',day:'numeric'});
    (groups[key]=groups[key]||[]).push(h);
  });
  let html='';
  Object.entries(groups).forEach(([day,items])=>{
    html+=`<div class="hist-day">${day}</div>`;
    items.forEach(h=>{
      const v=videoById(h.videoId); if(!v)return;
      html+=listRow(v, `<button class="icon-btn lr-remove" data-action="remove-history" data-video="${v.id}">${ic('close',16)}</button>`);
    });
  });
  view.innerHTML+=html;
}
function listRow(v,rightHtml,idx){
  const ch=channelDisplay(v);
  return `<div class="list-row">
    ${idx!=null?`<div class="idx">${idx}</div>`:''}
    <div data-action="nav" data-route="/watch" data-query="v=${v.id}" style="display:flex;gap:14px;flex:1;min-width:0">
      <div class="thumb-wrap"><img src="${v.thumb}" alt=""><span class="duration-badge">${v.duration?fmtDur(v.duration):''}</span></div>
      <div style="min-width:0"><div class="lr-title">${esc(v.title)}</div><div class="lr-meta">${esc(ch.name)} · ${v.views==null?'':fmtViews(v.views)+' views'}</div></div>
    </div>
    ${rightHtml||''}
  </div>`;
}

async function viewWatchLater(){
  const view=document.getElementById('view');
  view.innerHTML = `<div class="view-header"><div><span class="eyebrow">Saved</span><h1 class="view-title">${ic('clock',22)} Watch later</h1></div></div>`;
  const ids=[...state.watchLater];
  if(!ids.length){ view.innerHTML+=emptyState('clock','Nothing saved','Tap "Watch later" on any video to save it here.'); return; }
  view.innerHTML += ids.map(id=>{
    const v=videoById(id); if(!v)return '';
    return listRow(v,`<button class="icon-btn lr-remove" data-action="toggle-watchlater" data-video="${v.id}">${ic('close',16)}</button>`);
  }).join('');
}
async function viewLiked(){
  const view=document.getElementById('view');
  view.innerHTML = `<div class="view-header"><div><span class="eyebrow">Reactions</span><h1 class="view-title">${ic('thumbUp',22)} Liked videos</h1></div></div>`;
  const ids=[...state.likes.entries()].filter(([,v])=>v===1).map(([id])=>id);
  if(!ids.length){ view.innerHTML+=emptyState('thumbUp','No liked videos','Videos you like will be saved here.'); return; }
  view.innerHTML += `<div class="grid">${ids.map(id=>videoById(id)).filter(Boolean).map(videoCard).join('')}</div>`;
}
async function viewFavorites(){
  const view=document.getElementById('view');
  view.innerHTML = `<div class="view-header"><div><span class="eyebrow">Collection</span><h1 class="view-title">${ic('star',22)} Favorites</h1></div></div>`;
  const ids=[...state.favorites];
  if(!ids.length){ view.innerHTML+=emptyState('star','No favorites yet','Star videos you love to build your favorites collection.'); return; }
  view.innerHTML += `<div class="grid">${ids.map(id=>videoById(id)).filter(Boolean).map(videoCard).join('')}</div>`;
}
function playlistCard(p){
  const first=videoById(p.videoIds[0]);
  return `<div class="pl-card" data-action="nav" data-route="/playlist/${p.id}">
    <div class="pl-thumb"><img src="${first?first.thumb:thumbUrl(p.id)}" alt="">
      <div class="pl-count">${ic('list',13)} ${p.videoIds.length}</div></div>
    <div class="pl-info"><h4>${esc(p.name)}</h4><span>Playlist</span></div>
  </div>`;
}
async function viewPlaylists(){
  const view=document.getElementById('view');
  view.innerHTML = `<div class="view-header">
    <div><span class="eyebrow">Collections</span><h1 class="view-title">${ic('list',22)} Playlists</h1></div>
    <button class="btn btn-primary btn-sm" data-action="open-new-playlist">${ic('plus',15)}New playlist</button>
  </div>`;
  if(!state.playlists.length){ view.innerHTML+=emptyState('list','No playlists','Create a playlist to start organizing videos.'); return; }
  view.innerHTML += `<div class="grid compact">${state.playlists.map(playlistCard).join('')}</div>`;
}
async function viewPlaylistDetail(r){
  const view=document.getElementById('view');
  const p=state.playlists.find(pl=>pl.id===r.param);
  if(!p){ view.innerHTML=emptyState('list','Playlist not found','This playlist may have been deleted.'); return; }
  view.innerHTML = `<div class="view-header">
    <div><span class="eyebrow">Playlist</span><h1 class="view-title">${esc(p.name)}</h1><div class="view-sub">${p.videoIds.length} videos</div></div>
    ${!p.system?`<button class="btn btn-outline btn-sm" data-action="delete-playlist" data-playlist="${p.id}">${ic('trash',15)}Delete</button>`:''}
  </div>`;
  if(!p.videoIds.length){ view.innerHTML+=emptyState('list','Playlist is empty','Add videos to this playlist from the save menu on any video.'); return; }
  view.innerHTML += p.videoIds.map((id,i)=>{
    const v=videoById(id); if(!v)return '';
    return listRow(v,`<button class="icon-btn lr-remove" data-action="remove-from-playlist" data-playlist="${p.id}" data-video="${v.id}">${ic('close',16)}</button>`, i+1);
  }).join('');
}

async function viewSettings(){
  const view=document.getElementById('view');
  view.innerHTML = `
    <div class="view-header"><div><span class="eyebrow">Preferences</span><h1 class="view-title">${ic('settings',22)} Settings</h1></div></div>
    <div class="settings-grid">
      <div class="settings-card">
        <h3>${ic('sun',17)} Appearance</h3>
        <div class="sc-desc">Choose how NexVibe looks on this device.</div>
        <div class="setting-row"><div><div class="sr-label">Theme</div><div class="sr-hint">Dark is easier on the eyes, light suits bright rooms.</div></div>
          <button class="theme-switch" data-action="toggle-theme"><span class="knob">${state.theme==='dark'?ic('moon',12):ic('sun',12)}</span></button></div>
      </div>
      <div class="settings-card">
        <h3>${ic('play',17)} Playback</h3>
        <div class="sc-desc">Control what happens after a video ends.</div>
        <div class="setting-row"><div><div class="sr-label">Autoplay next video</div><div class="sr-hint">Plays a related video automatically.</div></div>
          <div class="mini-switch ${state.autoplay?'on':''}" data-action="toggle-autoplay"><div class="k"></div></div></div>
        <div class="setting-row"><div><div class="sr-label">Default quality</div><div class="sr-hint">Applies to supported streams.</div></div>
          <select class="select-field" id="qualitySelect"><option>Auto</option><option>1080p</option><option>720p</option><option>480p</option></select></div>
      </div>
      <div class="settings-card">
        <h3>${ic('key',17)} YouTube Data API</h3>
        <div class="sc-desc">Add your own YouTube Data API v3 key to pull live search, trending and channel data. Without a key, NexVibe runs on curated demo content.</div>
        <div class="field"><label>API key</label><input class="text-field" id="apiKeyInput" type="password" placeholder="AIza..." value="${esc(state.apiKey)}"></div>
        <div class="setting-row"><div><div class="sr-label">Use live YouTube data</div><div class="sr-hint">${state.apiKey?'Key saved for this session.':'Enter a key to enable this.'}</div></div>
          <div class="mini-switch ${state.useApi?'on':''}" data-action="toggle-use-api"><div class="k"></div></div></div>
        <div class="setting-row"><div><div class="sr-label">Region</div><div class="sr-hint">Used for trending results.</div></div>
          <select class="select-field" id="regionSelect">
            ${['US','GB','PK','IN','CA','AU','DE','JP'].map(cc=>`<option ${state.region===cc?'selected':''}>${cc}</option>`).join('')}
          </select></div>
        <div class="setting-row"><div class="sr-label">Status</div><span class="status-pill ${state.useApi&&state.apiKey?'on':'off'}">${state.useApi&&state.apiKey?'Connected':'Not connected'}</span></div>
        <div style="margin-top:14px"><button class="btn btn-primary btn-sm" data-action="save-api-key">Save key</button></div>
      </div>
      <div class="settings-card">
        <h3>${ic('user',17)} Account</h3>
        <div class="sc-desc">${state.user?'Signed in for this session.':'You are browsing as a guest.'}</div>
        ${state.user?`
        <div class="field"><label>Display name</label><input class="text-field" id="nameInput" value="${esc(state.user.name)}"></div>
        <button class="btn btn-outline btn-sm" data-action="save-name">Save name</button>
        <div style="margin-top:14px"><button class="btn btn-danger btn-sm" data-action="sign-out">${ic('logout',15)}Sign out</button></div>
        `:`<button class="btn btn-primary btn-sm" data-action="open-signin">Sign in</button>`}
      </div>
      <div class="settings-card">
        <h3>${ic('trash',17)} Data</h3>
        <div class="sc-desc">All NexVibe data lives in this session only and resets on reload — nothing is uploaded anywhere.</div>
        <button class="btn btn-outline btn-sm" data-action="clear-history">Clear watch history</button>
        <div style="height:8px"></div>
        <button class="btn btn-danger btn-sm" data-action="reset-all">Reset all data</button>
      </div>
      <div class="settings-card">
        <h3>${ic('info',17)} About</h3>
        <div class="sc-desc">NexVibe — Watch what's next.</div>
        <div class="setting-row"><div><div class="sr-label">Developed by</div><div class="sr-hint">Hania Batool</div></div></div>
        <div class="setting-row"><div><div class="sr-label">Version</div><div class="sr-hint">1.0.0</div></div></div>
      </div>
    </div>
  `;
}

/* ---------------------------------- MODALS ---------------------------------- */
function openModal(html){
  document.getElementById('modal-root').innerHTML = `<div class="modal-backdrop" data-action="close-modal">${html}</div>`;
}
function closeModal(){ document.getElementById('modal-root').innerHTML=''; }
function openSignIn(){
  openModal(`
    <div class="modal" data-stop="1">
      <div class="modal-top"><h2>Welcome to NexVibe</h2><button class="icon-btn" data-action="close-modal">${ic('close',18)}</button></div>
      <div class="auth-tabs"><button class="active" data-action="auth-tab" data-tab="signin">Sign in</button><button data-action="auth-tab" data-tab="signup">Create account</button></div>
      <form data-action="submit-auth" id="authForm">
        <div class="field" id="nameField" style="display:none"><label>Name</label><input type="text" id="authName" placeholder="Your name"></div>
        <div class="field"><label>Email</label><input type="email" id="authEmail" placeholder="you@example.com" required></div>
        <div class="field"><label>Password</label><input type="password" id="authPassword" placeholder="••••••••" minlength="6" required></div>
        <div id="authError" style="color:var(--danger);font-size:12.5px;margin:-6px 0 12px;display:none"></div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center" id="authSubmitBtn">Sign in</button>
      </form>
      <div class="demo-box">Real account, powered by Supabase. Your email and password are securely handled by Supabase Auth — nothing is stored in this app itself.</div>
    </div>
  `);
}
function openShare(video){
  const link=`https://nexvibe.app/watch?v=${video.id}`;
  const socials=[['Copy link','copy',()=>{}],['X','share',()=>{}],['Reddit','share',()=>{}],['Mail','share',()=>{}]];
  openModal(`
    <div class="modal" data-stop="1">
      <div class="modal-top"><h2>Share</h2><button class="icon-btn" data-action="close-modal">${ic('close',18)}</button></div>
      <div class="share-grid">
        <button data-action="copy-link" data-link="${esc(link)}"><span class="sic" style="background:linear-gradient(135deg,var(--cyan),var(--cyan-dim))">${ic('link',16)}</span>Copy link</button>
        <button data-action="copy-link" data-link="${esc(link)}"><span class="sic" style="background:#1d9bf0">𝕏</span>X</button>
        <button data-action="copy-link" data-link="${esc(link)}"><span class="sic" style="background:#ff4500">R</span>Reddit</button>
        <button data-action="copy-link" data-link="${esc(link)}"><span class="sic" style="background:var(--orange)">✉</span>Mail</button>
      </div>
      <div class="share-link-row"><input readonly value="${esc(link)}" id="shareLinkField"><button class="btn btn-primary btn-sm" data-action="copy-link" data-link="${esc(link)}">Copy</button></div>
      <div class="demo-box">Embed: <span class="mono">&lt;iframe src="${esc(link.replace('watch?v=','embed/'))}"&gt;&lt;/iframe&gt;</span></div>
    </div>
  `);
}
function openSaveMenu(videoId, anchorEl){
  document.querySelectorAll('.pl-popover').forEach(e=>e.remove());
  const rect=anchorEl.getBoundingClientRect();
  const pop=document.createElement('div');
  pop.className='pl-popover';
  pop.style.top=(rect.bottom+window.scrollY+6)+'px';
  pop.style.left=Math.max(10,rect.left+window.scrollX-230)+'px';
  const allPlaylists = state.playlists;
  pop.innerHTML = `
    <h4>Save video to...</h4>
    ${allPlaylists.map(p=>{
      const checked = p.id==='pl_watchlater' ? state.watchLater.has(videoId) : p.videoIds.includes(videoId);
      return `<label class="pl-check"><input type="checkbox" data-action="pl-check" data-playlist="${p.id}" data-video="${videoId}" ${checked?'checked':''}>${esc(p.name)}</label>`;
    }).join('')}
    <label class="pl-check"><input type="checkbox" data-action="fav-check" data-video="${videoId}" ${state.favorites.has(videoId)?'checked':''}>Favorites</label>
    <div class="pl-new"><input type="text" placeholder="New playlist name" id="newPlName"><button class="btn btn-ghost btn-sm" data-action="create-playlist-inline" data-video="${videoId}">${ic('plus',14)}</button></div>
  `;
  document.body.appendChild(pop);
  setTimeout(()=>document.addEventListener('click',outsideCloseOnce),0);
  function outsideCloseOnce(e){ if(!pop.contains(e.target)){ pop.remove(); document.removeEventListener('click',outsideCloseOnce); } }
}

/* ---------------------------------- EVENT DELEGATION ---------------------------------- */
document.addEventListener('click', async (e)=>{
  const stopEl = e.target.closest('[data-stop]');
  const el = e.target.closest('[data-action]');
  if(!el) return;
  if(stopEl && stopEl!==el && stopEl.contains(el)) e.stopPropagation();
  const action = el.dataset.action;

  switch(action){
    case 'nav': {
      e.preventDefault();
      const route=el.dataset.route; const q=el.dataset.query;
      location.hash = '#'+route+(q?'?'+q:'');
      break;
    }
    case 'toggle-sidebar-mobile': state.sidebarOpenMobile=!state.sidebarOpenMobile; renderSidebar(); break;
    case 'toggle-sidebar-desktop': state.sidebarCollapsed=!state.sidebarCollapsed; renderSidebar(); break;
    case 'toggle-theme': {
      state.theme = state.theme==='dark'?'light':'dark';
      document.documentElement.setAttribute('data-theme', state.theme);
      renderTopbar(); if(state.route.path==='/settings') viewSettings();
      break;
    }
    case 'set-cat': location.hash='#/home?cat='+el.dataset.cat; break;
    case 'set-trend-tab': location.hash='#/trending?tab='+el.dataset.tab; break;
    case 'submit-search': break; // handled by submit listener
    case 'focus-search': document.getElementById('searchInput')?.focus(); break;
    case 'toggle-notifications': {
      closePopovers();
      const unread=state.notifications.filter(n=>n.unread).length;
      openPanel(el, `
        <div class="panel-head"><h4>Notifications</h4>${unread?`<button class="btn btn-ghost btn-sm" data-action="mark-read">Mark all read</button>`:''}</div>
        <div class="panel-body">${state.notifications.length?state.notifications.map(n=>{
          const v=videoById(n.videoId); const c=CHANNELS[n.channelId];
          return `<div class="notif-item ${n.unread?'unread':''}" data-action="nav" data-route="/watch" data-query="v=${n.videoId}">
            <img src="${c?c.avatar:avatarUrl(n.channelId)}" alt="">
            <div><div class="n-title"><b>${esc(c?c.name:'A channel')}</b> uploaded: ${esc(v?v.title:'a new video')}</div><div class="n-meta">${timeAgoShort(n.ts)}</div></div>
            ${n.unread?'<span class="notif-dot"></span>':''}
          </div>`;
        }).join(''):`<div style="padding:30px">${emptyState('bell','No notifications','You are all caught up.')}</div>`}</div>
      `);
      break;
    }
    case 'mark-read': state.notifications.forEach(n=>n.unread=false); closePopovers(); renderTopbar(); break;
    case 'toggle-account': {
      closePopovers();
      openPanel(el, `
        <div class="panel-body">
          <div class="menu-item" data-action="nav" data-route="/channel/me">${ic('user',17)}Your channel</div>
          <div class="menu-item" data-action="nav" data-route="/settings">${ic('user',17)}Your account</div>
          <div class="menu-item" data-action="nav" data-route="/liked">${ic('thumbUp',17)}Liked videos</div>
          <div class="menu-item" data-action="nav" data-route="/history">${ic('history',17)}History</div>
          <div class="menu-item" data-action="nav" data-route="/settings">${ic('settings',17)}Settings</div>
          <div class="menu-item" data-action="sign-out">${ic('logout',17)}Sign out</div>
        </div>
      `);
      break;
    }
    case 'open-signin': openSignIn(); break;
    case 'close-modal': if(e.target===el) closeModal(); break;
    case 'auth-tab': {
      el.parentElement.querySelectorAll('button').forEach(b=>b.classList.remove('active'));
      el.classList.add('active');
      const isSignup = el.dataset.tab==='signup';
      document.getElementById('nameField').style.display = isSignup ? 'block' : 'none';
      document.getElementById('authSubmitBtn').textContent = isSignup ? 'Create account' : 'Sign in';
      document.getElementById('authForm').dataset.mode = el.dataset.tab;
      break;
    }
    case 'sign-out': {
      realSignOut();
      closePopovers(); toast('Signed out'); if(state.route.path==='/settings') viewSettings();
      break;
    }
    case 'toggle-sub': {
      const cid=el.dataset.channel;
      if(state.subscriptions.has(cid)){ state.subscriptions.delete(cid); toast('Unsubscribed'); }
      else { state.subscriptions.add(cid); toast('Subscribed'); seedNotifications(); }
      renderSidebar(); renderTopbar();
      if(state.route.path==='/watch') renderWatchMeta(videoById(state.route.query.v));
      if(state.route.path==='/channel') route();
      break;
    }
    case 'like': {
      const vid=el.dataset.video, type=Number(el.dataset.type);
      const cur=state.likes.get(vid);
      state.likes.set(vid, cur===type ? undefined : type);
      if(cur===type) state.likes.delete(vid);
      renderWatchMeta(videoById(vid));
      break;
    }
    case 'toggle-watchlater': {
      const vid=el.dataset.video;
      const wl = state.playlists.find(p=>p.id==='pl_watchlater');
      if(state.watchLater.has(vid)){ state.watchLater.delete(vid); wl.videoIds=wl.videoIds.filter(x=>x!==vid); toast('Removed from Watch later'); }
      else{ state.watchLater.add(vid); wl.videoIds.push(vid); toast('Saved to Watch later'); }
      if(state.route.path==='/watch') renderWatchMeta(videoById(state.route.query.v));
      if(state.route.path==='/watchlater') viewWatchLater();
      break;
    }
    case 'toggle-favorite': {
      const vid=el.dataset.video;
      if(state.favorites.has(vid)){ state.favorites.delete(vid); toast('Removed from Favorites'); }
      else{ state.favorites.add(vid); toast('Added to Favorites'); }
      if(state.route.path==='/watch') renderWatchMeta(videoById(state.route.query.v));
      if(state.route.path==='/favorites') viewFavorites();
      break;
    }
    case 'open-save-menu': { e.stopPropagation(); openSaveMenu(el.dataset.video, el); break; }
    case 'pl-check': break;
    case 'open-share': { const v=videoById(el.dataset.video); openShare(v); break; }
    case 'copy-link': {
      const link=el.dataset.link || document.getElementById('shareLinkField')?.value;
      try{ await navigator.clipboard.writeText(link); toast('Link copied'); }catch(err){ toast('Could not copy link', {err:true}); }
      break;
    }
    case 'toggle-desc': {
      const box=document.getElementById('descBox');
      box.classList.toggle('collapsed');
      box.querySelector('.more').textContent = box.classList.contains('collapsed') ? 'Show more' : 'Show less';
      break;
    }
    case 'submit-comment': break;
    case 'clear-comment': { const ta=document.getElementById('commentInput'); if(ta) ta.value=''; break; }
    case 'like-comment': {
      const vid=el.dataset.video, cid=el.dataset.cid;
      const list=ensureComments(vid); const c=list.find(x=>x.id===cid);
      c.liked=!c.liked; c.likes += c.liked?1:-1;
      document.getElementById('commentsList').innerHTML = list.map(c=>commentItem(c,vid)).join('');
      break;
    }
    case 'reply-comment': {
      const vid=el.dataset.video, cid=el.dataset.cid;
      const box=document.getElementById('replies-'+cid);
      if(box.querySelector('.reply-form')) break;
      box.insertAdjacentHTML('afterbegin', `<form class="comment-form reply-form" data-action="submit-reply" data-video="${vid}" data-cid="${cid}" style="margin-bottom:14px">
        <img src="${state.user?state.user.avatar:personUrl('guest')}"><div class="cf-body"><textarea placeholder="Reply..." rows="1"></textarea>
        <div class="cf-actions"><button type="submit" class="btn btn-primary btn-sm">Reply</button></div></div></form>`);
      break;
    }
    case 'submit-reply': break;
    case 'toggle-autoplay': state.autoplay=!state.autoplay; document.querySelectorAll('.mini-switch[data-action="toggle-autoplay"]').forEach(s=>s.classList.toggle('on',state.autoplay)); break;
    case 'toggle-speed': { document.getElementById('speedPop').classList.toggle('show'); break; }
    case 'set-speed': {
      const rate=Number(el.dataset.rate);
      player?.setRate(rate);
      document.getElementById('speedBtn').textContent=rate+'x';
      el.parentElement.querySelectorAll('button').forEach(b=>b.classList.remove('active'));
      el.classList.add('active'); document.getElementById('speedPop').classList.remove('show');
      break;
    }
    case 'player-toggle': player?.toggle(); break;
    case 'player-mute': {
      const btn=document.getElementById('muteBtn'); const willMute = btn.dataset.muted!=='1';
      player?.setMuted(willMute); btn.dataset.muted = willMute?'1':'0'; btn.innerHTML = ic(willMute?'mute':'volume',17);
      break;
    }
    case 'player-fullscreen': {
      const shell=document.getElementById('playerShell');
      if(document.fullscreenElement) document.exitFullscreen(); else shell.requestFullscreen?.();
      break;
    }
    case 'channel-tab': location.hash = '#/channel/'+el.dataset.channel+'?tab='+el.dataset.tab; break;
    case 'clear-history': state.history=[]; toast('Watch history cleared'); if(state.route.path==='/history') viewHistory(); break;
    case 'remove-history': state.history=state.history.filter(h=>h.videoId!==el.dataset.video); viewHistory(); break;
    case 'open-new-playlist': {
      openModal(`<div class="modal" data-stop="1"><div class="modal-top"><h2>New playlist</h2><button class="icon-btn" data-action="close-modal">${ic('close',18)}</button></div>
        <form data-action="submit-new-playlist"><div class="field"><label>Name</label><input type="text" id="newPlaylistName" placeholder="e.g. Weekend watch" required></div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">Create</button></form></div>`);
      break;
    }
    case 'delete-playlist': {
      state.playlists = state.playlists.filter(p=>p.id!==el.dataset.playlist);
      toast('Playlist deleted'); location.hash='#/playlists';
      break;
    }
    case 'remove-from-playlist': {
      const p=state.playlists.find(pl=>pl.id===el.dataset.playlist);
      p.videoIds = p.videoIds.filter(id=>id!==el.dataset.video);
      if(p.id==='pl_watchlater') state.watchLater.delete(el.dataset.video);
      viewPlaylistDetail({param:p.id});
      break;
    }
    case 'create-playlist-inline': {
      const input=document.getElementById('newPlName'); const name=input.value.trim();
      if(!name){ toast('Enter a playlist name', {err:true}); break; }
      const np={id:'pl_'+uid(), name, system:false, videoIds:[el.dataset.video]};
      state.playlists.push(np); toast('Playlist created'); document.querySelectorAll('.pl-popover').forEach(x=>x.remove());
      break;
    }
    case 'save-api-key': {
      const val=document.getElementById('apiKeyInput').value.trim();
      state.apiKey = val;
      if(val){ state.useApi=true; toast('API key saved for this session'); } else { state.useApi=false; toast('API key cleared'); }
      viewSettings();
      break;
    }
    case 'toggle-use-api': {
      if(!state.apiKey){ toast('Add an API key first', {err:true}); break; }
      state.useApi=!state.useApi; viewSettings();
      break;
    }
    case 'save-name': {
      const val=document.getElementById('nameInput').value.trim();
      if(val && state.user){ state.user.name=val; toast('Name updated'); renderTopbar(); }
      break;
    }
    case 'reset-all': {
      state.likes.clear(); state.favorites.clear(); state.watchLater.clear(); state.history=[];
      state.playlists=[{id:'pl_watchlater',name:'Watch later',system:true,videoIds:[]}];
      state.subscriptions=new Set(); state.comments.clear();
      toast('All data reset'); route();
      break;
    }
    case 'retry-search': route(); break;
    default: break;
  }
  schedulePersist();
});

/* change / input / submit listeners */
document.addEventListener('submit', async (e)=>{
  const el=e.target.closest('[data-action]'); if(!el) return;
  e.preventDefault();
  const action=el.dataset.action;
  if(action==='submit-auth'){
    const mode = el.dataset.mode || 'signin';
    const email = document.getElementById('authEmail').value.trim();
    const password = document.getElementById('authPassword').value;
    const name = document.getElementById('authName')?.value.trim();
    const errBox = document.getElementById('authError');
    const btn = document.getElementById('authSubmitBtn');
    errBox.style.display='none';
    btn.disabled=true; btn.textContent = mode==='signup' ? 'Creating account…' : 'Signing in…';
    try{
      if(mode==='signup'){
        const result = await realSignUp(email, password, name || email.split('@')[0]);
        if(result.session){
          state.user = userFromSession(result.session);
          await loadUserData(); renderTopbar();
          toast('Account created and signed in');
          closeModal();
        } else {
          toast('Account created — check your email to confirm, then sign in', {err:false});
          errBox.textContent = 'Almost there: confirm your email, then come back and sign in.';
          errBox.style.color = 'var(--cyan)';
          errBox.style.display='block';
          btn.disabled=false; btn.textContent='Create account';
        }
      } else {
        try{
          const result = await realSignIn(email, password);
          state.user = userFromSession(result.session);
          await loadUserData(); renderTopbar();
          toast('Signed in');
          closeModal();
        }catch(signInErr){
          if(/Invalid login credentials/i.test(signInErr.message||'')){
            const result = await realSignUp(email, password, email.split('@')[0]);
            if(result.session){
              state.user = userFromSession(result.session);
              await loadUserData(); renderTopbar();
              toast('Account created and signed in');
              closeModal();
            } else {
              toast('Account created — check your email to confirm, then sign in');
              errBox.textContent = 'Almost there: confirm your email, then come back and sign in.';
              errBox.style.color = 'var(--cyan)';
              errBox.style.display='block';
              btn.disabled=false; btn.textContent='Sign in';
            }
          } else {
            throw signInErr;
          }
        }
      }
    }catch(err){
      errBox.textContent = err.message || 'Something went wrong';
      errBox.style.display='block';
      btn.disabled=false; btn.textContent = mode==='signup' ? 'Create account' : 'Sign in';
    }
  }
  if(action==='submit-search'){
    const q=document.getElementById('searchInput').value.trim();
    if(!q) return;
    if(!state.searchHistory.includes(q)) state.searchHistory.unshift(q);
    location.hash = '#/search?q='+encodeURIComponent(q);
  }
  if(action==='submit-comment'){
    const vid=el.dataset.video; const ta=document.getElementById('commentInput'); const text=ta.value.trim();
    if(!text) return;
    const list=ensureComments(vid);
    const newC = {id:uid(), author:state.user?state.user.name:'Guest viewer', avatar:state.user?state.user.avatar:personUrl('guest'),
      text, likes:0, ts:Date.now(), liked:false, replies:[]};
    list.unshift(newC);
    document.getElementById('commentsList').innerHTML=list.map(c=>commentItem(c,vid)).join('');
    document.querySelector('.comments-head h3').textContent = list.length+' Comments';
    ta.value=''; toast('Comment posted');
    saveCommentToDB(vid, newC);
  }
  if(action==='submit-reply'){
    const vid=el.dataset.video, cid=el.dataset.cid; const ta=el.querySelector('textarea'); const text=ta.value.trim();
    if(!text) return;
    const list=ensureComments(vid); const c=list.find(x=>x.id===cid);
    const reply={author:state.user?state.user.name:'Guest viewer', avatar:state.user?state.user.avatar:personUrl('guest'), text, ts:Date.now()};
    c.replies.push(reply);
    document.getElementById('commentsList').innerHTML=list.map(c=>commentItem(c,vid)).join('');
    toast('Reply posted');
    saveCommentToDB(vid, reply, c.id);
  }
  if(action==='submit-new-playlist'){
    const name=document.getElementById('newPlaylistName').value.trim();
    if(!name) return;
    state.playlists.push({id:'pl_'+uid(), name, system:false, videoIds:[]});
    closeModal(); toast('Playlist created'); if(state.route.path==='/playlists') viewPlaylists();
  }
  schedulePersist();
});
document.addEventListener('change', (e)=>{
  if(e.target.id==='apiKeyInput'){ /* saved on click */ }
  if(e.target.matches('[data-action="pl-check"]')){
    const pid=e.target.dataset.playlist, vid=e.target.dataset.video, checked=e.target.checked;
    const p=state.playlists.find(x=>x.id===pid);
    if(checked){ if(!p.videoIds.includes(vid)) p.videoIds.push(vid); if(pid==='pl_watchlater') state.watchLater.add(vid); }
    else{ p.videoIds=p.videoIds.filter(x=>x!==vid); if(pid==='pl_watchlater') state.watchLater.delete(vid); }
    toast(checked?'Added to '+p.name:'Removed from '+p.name);
    if(state.route.path==='/watch') renderWatchMeta(videoById(state.route.query.v));
  }
  if(e.target.matches('[data-action="fav-check"]')){
    const vid=e.target.dataset.video;
    if(e.target.checked) state.favorites.add(vid); else state.favorites.delete(vid);
    toast(e.target.checked?'Added to Favorites':'Removed from Favorites');
    if(state.route.path==='/watch') renderWatchMeta(videoById(state.route.query.v));
  }
  if(e.target.id==='regionSelect'){ state.region=e.target.value; toast('Region set to '+state.region); }
  schedulePersist();
});

/* live search suggestions */
let suggestTimer;
document.addEventListener('input', (e)=>{
  if(e.target.id==='searchInput'){
    clearTimeout(suggestTimer);
    const val=e.target.value.trim();
    const box=document.getElementById('searchSuggest');
    if(!val){ box.classList.remove('show'); return; }
    suggestTimer=setTimeout(()=>{
      const ql=val.toLowerCase();
      const matches = VIDEOS.filter(v=>v.title.toLowerCase().includes(ql)).slice(0,6);
      const hist = state.searchHistory.filter(h=>h.toLowerCase().includes(ql)).slice(0,3);
      if(!matches.length && !hist.length){ box.classList.remove('show'); return; }
      box.innerHTML = [
        ...hist.map(h=>`<div class="sg-item" data-action="pick-suggest" data-q="${esc(h)}">${ic('history',15)}${esc(h)}</div>`),
        ...matches.map(v=>`<div class="sg-item" data-action="pick-suggest" data-q="${esc(v.title)}">${ic('search',15)}${esc(v.title)}</div>`)
      ].join('');
      box.classList.add('show');
    },150);
  }
});
document.addEventListener('click', (e)=>{
  const el=e.target.closest('[data-action="pick-suggest"]');
  if(el){ location.hash='#/search?q='+encodeURIComponent(el.dataset.q); document.getElementById('searchSuggest').classList.remove('show'); }
  if(!e.target.closest('.searchbar')) document.getElementById('searchSuggest')?.classList.remove('show');
  if(e.target.id==='scrim'){ state.sidebarOpenMobile=false; renderSidebar(); }
});

/* ---------------------------------- POPOVER PANELS ---------------------------------- */
function closePopovers(){ document.querySelectorAll('.panel').forEach(p=>p.remove()); }
function openPanel(anchor, innerHtml){
  const wrap=anchor.closest('.rel') || anchor.parentElement;
  wrap.style.position='relative';
  const panel=document.createElement('div');
  panel.className='panel';
  panel.innerHTML=innerHtml;
  wrap.appendChild(panel);
  setTimeout(()=>document.addEventListener('click',outside),0);
  function outside(e){ if(!panel.contains(e.target) && e.target!==anchor && !anchor.contains(e.target)){ panel.remove(); document.removeEventListener('click',outside); } }
}

/* ---------------------------------- INIT ---------------------------------- */
document.documentElement.setAttribute('data-theme', state.theme);
(async function(){
  await route();
  initSupabaseAuth();
  setTimeout(()=>{
    const splash=document.getElementById('splashScreen');
    if(splash){ splash.classList.add('hide'); setTimeout(()=>splash.remove(),600); }
  }, 350);
})();
